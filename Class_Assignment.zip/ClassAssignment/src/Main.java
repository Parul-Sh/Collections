import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {

	public static void main(String[] args) {
       List<Employee> a=new ArrayList<Employee>();
        a.add(new Employee("Parul","Indore",50000));
        a.add(new Employee("Parul","Bhopal",60000));
        a.add(new Employee("M","Indore",6000));
        
        
        Collections.sort(a, new Comparator<Employee>(){

			@Override
			public int compare(Employee o1, Employee o2) {
				// TODO Auto-generated method stub
				if((o1.getName()).equals(o2.getName())){
					if((o1.getSalary())==(o2.getSalary()))
						return o1.getCity().compareTo(o2.getCity());
					else
					return Integer.compare((o1.getSalary()),o2.getSalary());
				}
				return o1.getName().compareTo(o2.getName());
				
			}
        	
        	
        });
        	
	System.out.println(a);
      
      
        
	}


}
